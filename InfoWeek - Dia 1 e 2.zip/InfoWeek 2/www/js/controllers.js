angular.module('starter.controllers', [])

  .controller('GanhosCtrl', function ($scope,firebaseData,$firebaseArray,$rootScope) {
    $scope.ganhos = $firebaseArray(firebaseData.refGanhos())
    $scope.addGanho = function (e) {
      $scope.ganhos.$add({
        nome: $scope.nome,
        valor: $scope.valor
      });
      $scope.nome = "";
      $scope.valor = 0;
    };
    $scope.getTotal = function () {
      var rtnTotal = 0;
      for (var i = 0; i < $scope.ganhos.length; i++) {
        rtnTotal += $scope.ganhos[ i ].valor;
      }
      $rootScope.totalGanhos = rtnTotal
      return rtnTotal;
    };
  })

  .controller('DespesasCtrl', function ($scope,firebaseData,$firebaseArray,$rootScope) {
    $scope.despesas = $firebaseArray(firebaseData.refDespesas())
    $scope.addDespesa = function (e) {
      $scope.despesas.$add({
        nome: $scope.nome,
        valor: $scope.valor
      });
      $scope.nome = "";
      $scope.valor = 0;
    };
    $scope.getTotal = function () {
      var rtnTotal = 0;
      for (var i = 0; i < $scope.despesas.length; i++) {
        rtnTotal += $scope.despesas[ i ].valor;
      }
      $rootScope.totalDespesas = rtnTotal;
      return rtnTotal;
    };
  })

  .controller('BalancoCtrl', function ($scope,$rootScope) {
    $scope.calculaBalanco = function(){
      var total = $rootScope.totalGanhos - $rootScope.totalDespesas;
      return total;
    }
  })

  .controller('ContaCtrl', function ($scope) {});
