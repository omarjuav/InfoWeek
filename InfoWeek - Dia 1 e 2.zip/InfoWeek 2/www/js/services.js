angular.module('starter.services', [])

//Os serviços vão aqui

.factory('firebaseData',function($firebase){
	var config = {
    apiKey: "AIzaSyDX42grQ5PkbY1hzchoVFTVmy3YUoCr2G0",
    authDomain: "gerenciador-financeiro-dea1a.firebaseapp.com",
    databaseURL: "https://gerenciador-financeiro-dea1a.firebaseio.com",
    storageBucket: "gerenciador-financeiro-dea1a.appspot.com",
    messagingSenderId: "662740028020"
  };
  firebase.initializeApp(config);

  var ref = firebase.database().ref();

  return {
  	ref: function(){
  		return ref;
  	},
 	refGanhos : function(){
 		return ref.child('ganhos');
 	},
 	refDespesas: function(){
 		return ref.child('despesas');
 	}
  }
})