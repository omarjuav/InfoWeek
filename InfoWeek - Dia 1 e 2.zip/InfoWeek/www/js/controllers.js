angular.module('starter.controllers', [])

.controller('GanhosCtrl', function($scope) {
	$scope.ganhos = [];
	$scope.addGanho = function (event) {
		$scope.ganhos.push({
			nome: $scope.nome,
			valor: $scope.valor
		})
		$scope.nome = "";
		$scope.valor = "";
	}

	$scope.getTotal = function(){
		var total = 0;
		for(var i = 0; i <$scope.ganhos.length; i++){
			total = total +	 $scope.ganhos[i].valor;	
		}
		return total;
	}
})

.controller('DespesasCtrl', function($scope) {
	$scope.gastos = [];
	$scope.addGasto = function(event){
		$scope.gastos.push({
			nome: $scope.nome,
			valor: $scope.valor
		})
		$scope.nome = "";
		$scope.valor = "";
	}

	$scope.getTotal = function(){
		var total = 0;
		for(var i = 0; i<$scope.gastos.length; i++){
			total = total + $scope.gastos[i].valor;
		}
		return total *(-1);
	}
})

.controller('BalancoCtrl', function($scope) {})

.controller('ContaCtrl', function($scope) {});
