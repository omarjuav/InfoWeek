angular.module('starter.services', [])

//Os serviços vão aqui
